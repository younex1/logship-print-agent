#!/usr/bin/env node

// src/cli.ts
import os4 from "node:os";

// src/config.ts
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from "node:fs";
import path from "node:path";
var VERSION = "0.1.1" ? "0.1.1" : process.env.LOGSHIP_AGENT_VERSION || "dev";
var ENV_FILE = process.env.LOGSHIP_AGENT_ENV || "/etc/logship-print-agent/agent.env";
var parseEnvFile = (text) => {
  const out = {};
  for (const raw of String(text || "").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq <= 0) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if (val.startsWith('"') && val.endsWith('"') || val.startsWith("'") && val.endsWith("'")) val = val.slice(1, -1);
    out[key] = val;
  }
  return out;
};
var readEnvFile = (file = ENV_FILE) => {
  try {
    return existsSync(file) ? parseEnvFile(readFileSync(file, "utf8")) : {};
  } catch {
    return {};
  }
};
var writeEnvFile = (updates, file = ENV_FILE) => {
  const dir = path.dirname(file);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const existing = existsSync(file) ? readFileSync(file, "utf8").split(/\r?\n/) : [];
  const seen = /* @__PURE__ */ new Set();
  const lines = existing.map((raw) => {
    const m = /^\s*([A-Z0-9_]+)\s*=/.exec(raw);
    if (m && updates[m[1]] !== void 0) {
      seen.add(m[1]);
      return `${m[1]}=${updates[m[1]]}`;
    }
    return raw;
  });
  for (const [k, v] of Object.entries(updates)) if (!seen.has(k)) lines.push(`${k}=${v}`);
  writeFileSync(file, lines.filter((l, i, a) => !(l === "" && i === a.length - 1)).join("\n") + "\n", { mode: 384 });
  try {
    chmodSync(file, 384);
  } catch {
  }
};
var bool = (v, d) => v === void 0 || v === "" ? d : !["0", "false", "no", "off"].includes(String(v).toLowerCase());
var num = (v, d) => {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : d;
};
var loadConfig = () => {
  const f = readEnvFile();
  const get = (k, d = "") => process.env[k] ?? f[k] ?? d;
  const stateDir = get("STATE_DIR", "/var/lib/logship-print-agent");
  const cfg = {
    envFile: ENV_FILE,
    url: get("LOGSHIP_URL").replace(/\/+$/, ""),
    token: get("LOGSHIP_AGENT_TOKEN"),
    name: get("LOGSHIP_AGENT_NAME", "Print-Agent"),
    stateDir,
    spoolDir: get("SPOOL_DIR", path.join(stateDir, "spool")),
    pollWait: Math.min(num(get("POLL_WAIT"), 25), 25),
    pollMax: Math.min(num(get("POLL_MAX"), 50), 100),
    heartbeatSeconds: num(get("HEARTBEAT_SECONDS"), 60),
    completionPollMs: num(get("COMPLETION_POLL_MS"), 2e3),
    maxActivePerQueue: Math.min(num(get("MAX_ACTIVE_PER_QUEUE"), 40), 400),
    setupPort: num(get("SETUP_PORT"), 8080),
    setupBind: get("SETUP_BIND", "0.0.0.0"),
    autoProvisionUsb: bool(get("AUTO_PROVISION_USB"), true),
    autoProvisionMakes: get("AUTO_PROVISION_MAKES", "Zebra").split(",").map((s) => s.trim()).filter(Boolean),
    autoProvisionDriver: get("AUTO_PROVISION_DRIVER", "drv:///sample.drv/zebra.ppd"),
    ppdDir: get("CUPS_PPD_DIR", "/etc/cups/ppd"),
    backupEnabled: bool(get("BACKUP_ENABLED"), true),
    supportUnit: get("SUPPORT_UNIT", "logship-print-support.service"),
    cupsAdminUser: get("CUPS_ADMIN_USER", ""),
    cupsAdminPass: get("CUPS_ADMIN_PASS", ""),
    allowHttpRelay: bool(get("ALLOW_HTTP_RELAY"), true),
    allowSupportTunnel: bool(get("ALLOW_SUPPORT_TUNNEL"), true)
  };
  for (const d of [cfg.stateDir, cfg.spoolDir]) {
    try {
      if (!existsSync(d)) mkdirSync(d, { recursive: true });
    } catch {
    }
  }
  return cfg;
};
var isEnrolled = (cfg) => !!(cfg.url && cfg.token);

// src/api.ts
var ApiError = class extends Error {
  status;
  body;
  constructor(status, message, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
  get unauthorized() {
    return this.status === 401 || this.status === 403;
  }
};
var ua = `logship-print-agent/${VERSION} (node ${process.version})`;
var Api = class _Api {
  url;
  token;
  constructor(url, token) {
    this.url = url;
    this.token = token;
  }
  async req(method, path5, body, opts = {}) {
    const headers = { "User-Agent": ua, Accept: "application/json" };
    if (opts.auth !== false) headers.Authorization = `Bearer ${this.token}`;
    if (body !== void 0) headers["Content-Type"] = "application/json";
    const res = await fetch(this.url + path5, {
      method,
      headers,
      body: body === void 0 ? void 0 : JSON.stringify(body),
      signal: AbortSignal.timeout(opts.timeoutMs ?? 3e4)
    });
    if (!res.ok) {
      let detail = null;
      try {
        detail = await res.json();
      } catch {
        try {
          detail = await res.text();
        } catch {
        }
      }
      throw new ApiError(res.status, `${method} ${path5} \u2192 ${res.status} ${detail?.statusMessage || detail?.message || res.statusText}`, detail);
    }
    if (opts.raw) return Buffer.from(await res.arrayBuffer());
    return await res.json();
  }
  static async enroll(url, code, meta) {
    const api = new _Api(url.replace(/\/+$/, ""), "");
    return api.req(
      "POST",
      "/api/print-agent/enroll",
      { code, ...meta },
      { auth: false }
    );
  }
  heartbeat(body) {
    return this.req("POST", "/api/print-agent/heartbeat", body);
  }
  next(wait, max, fresh = false) {
    return this.req("GET", `/api/print-agent/jobs/next?wait=${wait}&max=${max}${fresh ? "&fresh=1" : ""}`, void 0, { timeoutMs: wait * 1e3 + 15e3 });
  }
  file(id) {
    return this.req("GET", `/api/print-agent/jobs/${id}/file`, void 0, { raw: true, timeoutMs: 12e4 });
  }
  ack(acks) {
    if (!acks.length) return Promise.resolve({ ok: true, results: [] });
    return this.req("POST", "/api/print-agent/jobs/ack", { acks });
  }
  commandResult(id, ok, result) {
    return this.req("POST", `/api/print-agent/commands/${id}/result`, { ok, result: String(result || "").slice(0, 8 * 1024 * 1024) }, { timeoutMs: 6e4 });
  }
  uploadBackup(tar) {
    return this.req("POST", "/api/print-agent/backup", { tarBase64: tar.toString("base64") }, { timeoutMs: 12e4 });
  }
  async downloadBackup() {
    try {
      return await this.req("GET", "/api/print-agent/backup", void 0, { raw: true, timeoutMs: 12e4 });
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) return null;
      throw e;
    }
  }
};

// src/cups.ts
import { execFile } from "node:child_process";
import { readFile } from "node:fs/promises";
import path2 from "node:path";
var run = (cmd2, args, timeoutMs = 15e3) => new Promise((resolve) => {
  execFile(cmd2, args, { timeout: timeoutMs, maxBuffer: 4 * 1024 * 1024, encoding: "utf8" }, (err, stdout, stderr) => {
    resolve({ code: err ? typeof err.code === "number" ? err.code : 1 : 0, stdout: String(stdout || ""), stderr: String(stderr || err?.message || "") });
  });
});
var PT_TO_MM = 25.4 / 72;
var NAMED = {
  a3: { w: 297, h: 420 },
  a4: { w: 210, h: 297 },
  a5: { w: 148, h: 210 },
  a6: { w: 105, h: 148 },
  a7: { w: 74, h: 105 },
  a8: { w: 52, h: 74 },
  letter: { w: 215.9, h: 279.4 },
  legal: { w: 215.9, h: 355.6 }
};
var r1 = (n) => Math.round(n * 10) / 10;
var parsePageSizeToken = (token) => {
  const t = String(token || "").trim();
  if (!t) return null;
  let m = /^Custom\.(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)(mm|cm|in|pt|m)?$/i.exec(t);
  if (m) {
    const unit = (m[3] || "pt").toLowerCase();
    const f = unit === "mm" ? 1 : unit === "cm" ? 10 : unit === "in" ? 25.4 : unit === "m" ? 1e3 : PT_TO_MM;
    const w = r1(Number(m[1]) * f), h = r1(Number(m[2]) * f);
    return w > 0 && h > 0 ? { w, h } : null;
  }
  m = /^w(\d+(?:\.\d+)?)h(\d+(?:\.\d+)?)$/i.exec(t);
  if (m) {
    const w = r1(Number(m[1]) * PT_TO_MM), h = r1(Number(m[2]) * PT_TO_MM);
    return w > 0 && h > 0 ? { w, h } : null;
  }
  return NAMED[t.toLowerCase()] ? { ...NAMED[t.toLowerCase()] } : null;
};
var queueMedia = async (queue, ppdDir) => {
  const lo = await run("lpoptions", ["-p", queue]);
  let m = /(?:^|\s)(?:media|PageSize)=(\S+)/.exec(lo.stdout);
  let media = m ? parsePageSizeToken(m[1]) : null;
  if (!media) {
    try {
      const ppd = await readFile(path2.join(ppdDir, `${queue}.ppd`), "utf8");
      const d = /^\*DefaultPageSize:\s*(\S+)/m.exec(ppd);
      media = d ? parsePageSizeToken(d[1]) : null;
    } catch {
    }
  }
  if (!media) {
    const ll = await run("lpoptions", ["-p", queue, "-l"]);
    const line = ll.stdout.split(/\r?\n/).find((l) => /^(PageSize|media)\//i.test(l));
    const starred = line ? /\*(\S+)/.exec(line.split(":").slice(1).join(":")) : null;
    media = starred ? parsePageSizeToken(starred[1]) : null;
  }
  return media;
};
var ppdField = async (queue, ppdDir, field) => {
  try {
    const ppd = await readFile(path2.join(ppdDir, `${queue}.ppd`), "utf8");
    const m = new RegExp(`^\\*${field}:\\s*"?([^"\\n]+)"?`, "m").exec(ppd);
    return m ? m[1].trim() : "";
  } catch {
    return "";
  }
};
var listQueues = async (ppdDir) => {
  const [p, a, v, depth] = await Promise.all([run("lpstat", ["-p"]), run("lpstat", ["-a"]), run("lpstat", ["-v"]), queueDepth()]);
  const queues = /* @__PURE__ */ new Map();
  for (const line of p.stdout.split(/\r?\n/)) {
    const m = /^printer (\S+) (.+)$/.exec(line.trim());
    if (!m) continue;
    const rest = m[2];
    const state = /disabled/i.test(rest) ? "disabled" : /is printing/i.test(rest) ? "printing" : /is idle/i.test(rest) ? "idle" : rest.slice(0, 40);
    queues.set(m[1], { queue: m[1], state, accepting: true, deviceUri: "", makeModel: "", media: null, jobs: depth[m[1]] || 0 });
  }
  for (const line of a.stdout.split(/\r?\n/)) {
    const m = /^(\S+) (accepting|not accepting)/.exec(line.trim());
    if (m && queues.has(m[1])) queues.get(m[1]).accepting = m[2] === "accepting";
  }
  for (const line of v.stdout.split(/\r?\n/)) {
    const m = /^device for (\S+): (.+)$/.exec(line.trim());
    if (m && queues.has(m[1])) queues.get(m[1]).deviceUri = m[2].trim();
  }
  for (const q of queues.values()) {
    q.media = await queueMedia(q.queue, ppdDir);
    q.makeModel = await ppdField(q.queue, ppdDir, "NickName") || await ppdField(q.queue, ppdDir, "ModelName");
  }
  return [...queues.values()].sort((x, y) => x.queue.localeCompare(y.queue, void 0, { numeric: true }));
};
var queueOfJobId = (id) => id.slice(0, id.lastIndexOf("-"));
var jobIdsFrom = (stdout) => {
  const ids = /* @__PURE__ */ new Set();
  for (const line of stdout.split(/\r?\n/)) {
    const m = /^(\S+-\d+)\s/.exec(line.trim());
    if (m) ids.add(m[1]);
  }
  return ids;
};
var pendingJobIds = async () => jobIdsFrom((await run("lpstat", ["-o"])).stdout);
var completedJobIds = async () => jobIdsFrom((await run("lpstat", ["-W", "completed", "-o"])).stdout);
var queueDepth = async () => {
  const out = {};
  for (const id of await pendingJobIds()) {
    const q = queueOfJobId(id);
    out[q] = (out[q] || 0) + 1;
  }
  return out;
};
var submit = async (queue, optionTokens, file) => {
  const args = [...queue ? ["-d", queue] : [], ...optionTokens, file];
  const r = await run("lp", args, 6e4);
  const m = /request id is (\S+)/i.exec(r.stdout);
  return { ok: r.code === 0 && !!m, requestId: m ? m[1] : null, stdout: r.stdout, stderr: r.stderr };
};
var cancelAll = () => run("cancel", ["-a"]);
var restartCups = () => run("systemctl", ["restart", "cups"], 6e4);
var lpstatAll = () => run("lpstat", ["-t"]);
var discoverUsbPrinters = async () => {
  const r = await run("lpinfo", ["-v"], 2e4);
  const out = [];
  for (const line of r.stdout.split(/\r?\n/)) {
    const m = /^direct (usb:\/\/\S+)/.exec(line.trim());
    if (!m) continue;
    const uri = m[1];
    const u = /^usb:\/\/([^/]+)\/([^?]+)(?:\?serial=([^&]+))?/.exec(uri);
    out.push({ uri, make: decodeURIComponent(u?.[1] || ""), model: decodeURIComponent(u?.[2] || "").replace(/%20/g, " "), serial: decodeURIComponent(u?.[3] || "") });
  }
  return out;
};
var autoProvisionUsb = async (makes, driver, ppdDir) => {
  const printers = (await discoverUsbPrinters()).filter((p) => makes.some((mk) => p.make.toLowerCase().includes(mk.toLowerCase())));
  if (!printers.length) return [];
  const existing = await listQueues(ppdDir);
  const usedUris = new Set(existing.map((q) => q.deviceUri));
  const usedNames = new Set(existing.map((q) => q.queue));
  const created = [];
  for (const p of printers) {
    if (usedUris.has(p.uri)) continue;
    let n = 1;
    while (usedNames.has(`labelprinter-${n}`)) n++;
    const name = `labelprinter-${n}`;
    const r = await run("lpadmin", ["-p", name, "-E", "-v", p.uri, "-m", driver, "-o", "printer-is-shared=false", "-D", `${p.make} ${p.model}`.trim()], 6e4);
    if (r.code === 0) {
      created.push(name);
      usedNames.add(name);
      usedUris.add(p.uri);
    }
  }
  return created;
};

// src/backup.ts
import { spawn } from "node:child_process";

// src/log.ts
var ts = () => (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
var fmt = (args) => args.map((a) => a instanceof Error ? a.stack || a.message : typeof a === "string" ? a : JSON.stringify(a)).join(" ");
var log = {
  info: (...a) => console.log(`${ts()} INFO  ${fmt(a)}`),
  warn: (...a) => console.warn(`${ts()} WARN  ${fmt(a)}`),
  error: (...a) => console.error(`${ts()} ERROR ${fmt(a)}`),
  debug: (...a) => {
    if (process.env.LOGSHIP_AGENT_DEBUG) console.log(`${ts()} DEBUG ${fmt(a)}`);
  }
};
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// src/backup.ts
var createCupsBackup = () => new Promise((resolve, reject) => {
  const chunks = [];
  const p = spawn("tar", ["czf", "-", "-C", "/", "etc/cups"]);
  p.stdout.on("data", (d) => chunks.push(d));
  let err = "";
  p.stderr.on("data", (d) => {
    err += d.toString();
  });
  p.on("close", (code) => code === 0 ? resolve(Buffer.concat(chunks)) : reject(new Error(`tar failed (${code}): ${err}`)));
  p.on("error", reject);
});
var uploadCupsBackup = async (api) => {
  const tar = await createCupsBackup();
  const res = await api.uploadBackup(tar);
  log.info(`cups backup uploaded (${res?.bytes ?? tar.length} bytes)`);
  return res;
};
var restoreCupsBackup = async (api) => {
  const tar = await api.downloadBackup();
  if (!tar) {
    log.warn("no cups backup stored on the instance for this agent");
    return false;
  }
  await new Promise((resolve, reject) => {
    const p = spawn("tar", ["xzf", "-", "-C", "/"]);
    let err = "";
    p.stderr.on("data", (d) => {
      err += d.toString();
    });
    p.on("close", (code) => code === 0 ? resolve() : reject(new Error(`tar extract failed (${code}): ${err}`)));
    p.on("error", reject);
    p.stdin.end(tar);
  });
  const r = await run("systemctl", ["restart", "cups"], 6e4);
  log.info(`cups backup restored (${tar.length} bytes), cups restart ${r.code === 0 ? "ok" : "FAILED: " + r.stderr}`);
  return r.code === 0;
};
var scheduleBackups = (api) => {
  const tick = async () => {
    try {
      await uploadCupsBackup(api);
    } catch (e) {
      log.warn("cups backup failed:", e?.message || e);
    }
  };
  setTimeout(tick, 5 * 6e4).unref();
  const msUntil = () => {
    const d = /* @__PURE__ */ new Date();
    d.setHours(3, 30, 0, 0);
    if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
    return d.getTime() - Date.now();
  };
  const arm = () => setTimeout(async () => {
    await tick();
    arm();
  }, msUntil()).unref();
  arm();
};

// src/worker.ts
import { writeFile as writeFile2, unlink } from "node:fs/promises";
import path4 from "node:path";
import os3 from "node:os";

// src/ledger.ts
import { existsSync as existsSync2, readFileSync as readFileSync2, writeFileSync as writeFileSync2, renameSync } from "node:fs";
import path3 from "node:path";
var Ledger = class {
  file;
  spooled = {};
  dirty = false;
  cap;
  constructor(stateDir, cap = 5e3) {
    this.cap = cap;
    this.file = path3.join(stateDir, "ledger.json");
    try {
      if (existsSync2(this.file)) this.spooled = JSON.parse(readFileSync2(this.file, "utf8"))?.spooled || {};
    } catch {
      this.spooled = {};
    }
    setInterval(() => this.flush(), 2e3).unref();
  }
  has(jobId) {
    return Object.prototype.hasOwnProperty.call(this.spooled, String(jobId));
  }
  get(jobId) {
    return this.spooled[String(jobId)];
  }
  /** Jobs handed to lp whose completion has not been confirmed yet (restored after a restart). */
  open() {
    return Object.entries(this.spooled).filter(([, e]) => !e.done).map(([k, e]) => ({ jobId: Number(k), entry: e }));
  }
  /** Marks a job as completed/failed on the device — kept (for idempotency) but no longer tracked. */
  finish(jobId) {
    const e = this.spooled[String(jobId)];
    if (e && !e.done) {
      e.done = true;
      this.dirty = true;
    }
  }
  add(jobId, cupsJobId, queue, file) {
    this.spooled[String(jobId)] = { cupsJobId, queue, ts: Date.now(), file };
    const keys = Object.keys(this.spooled);
    if (keys.length > this.cap) {
      keys.sort((a, b) => this.spooled[a].ts - this.spooled[b].ts).slice(0, keys.length - this.cap).forEach((k) => {
        delete this.spooled[k];
      });
    }
    this.dirty = true;
    this.flush();
  }
  /** Adopts a job the server still has as 'spooled' (completion never confirmed) if we do not know it. */
  adopt(jobId, cupsJobId, queue) {
    if (this.has(jobId)) return false;
    this.spooled[String(jobId)] = { cupsJobId, queue, ts: Date.now() };
    this.dirty = true;
    return true;
  }
  flush() {
    if (!this.dirty) return;
    this.dirty = false;
    try {
      const tmp = this.file + ".tmp";
      writeFileSync2(tmp, JSON.stringify({ spooled: this.spooled }));
      renameSync(tmp, this.file);
    } catch {
      this.dirty = true;
    }
  }
};

// src/heartbeat.ts
import os from "node:os";
import { readFile as readFile2 } from "node:fs/promises";
var collectHealth = async () => {
  const health = {
    uptimeHours: Math.round(os.uptime() / 36) / 100,
    load: Math.round(os.loadavg()[0] * 100) / 100,
    memFreeMb: Math.round(os.freemem() / 1048576),
    agentVersion: VERSION
  };
  const df = await run("df", ["-Pm", "/"]);
  const line = df.stdout.trim().split(/\r?\n/).pop() || "";
  const parts = line.split(/\s+/);
  if (parts.length >= 4 && Number.isFinite(Number(parts[3]))) health.diskFreeMb = Number(parts[3]);
  try {
    const t = Number((await readFile2("/sys/class/thermal/thermal_zone0/temp", "utf8")).trim());
    if (Number.isFinite(t)) health.temp = Math.round(t / 1e3);
  } catch {
  }
  for (const dev of ["/dev/nvme0", "/dev/sda", "/dev/mmcblk0"]) {
    const r = await run("smartctl", ["-A", "-j", dev], 1e4);
    if (r.code !== 0 && !r.stdout) continue;
    try {
      const j = JSON.parse(r.stdout);
      const pct = j?.nvme_smart_health_information_log?.percentage_used;
      if (Number.isFinite(Number(pct))) {
        health.smartWear = Number(pct);
        health.smartDevice = dev;
        break;
      }
      const table = j?.ata_smart_attributes?.table || [];
      const wear = table.find((a) => /Wear_Leveling_Count|Percent_Lifetime_Remain|Media_Wearout_Indicator/i.test(a?.name || ""));
      if (wear && Number.isFinite(Number(wear.value))) {
        health.smartWear = 100 - Number(wear.value);
        health.smartDevice = dev;
        break;
      }
    } catch {
    }
  }
  const apt = await run("apt", ["list", "--upgradable"], 2e4);
  health.updateAvailable = /^logship-print-agent\//m.test(apt.stdout);
  return health;
};
var buildHeartbeat = async (cfg) => {
  if (cfg.autoProvisionUsb) {
    try {
      const created = await autoProvisionUsb(cfg.autoProvisionMakes, cfg.autoProvisionDriver, cfg.ppdDir);
      if (created.length) log.info(`auto-provisioned USB label printer queue(s): ${created.join(", ")}`);
    } catch (e) {
      log.warn("USB auto-provisioning failed:", e?.message || e);
    }
  }
  const [printers, depth, health] = await Promise.all([listQueues(cfg.ppdDir), queueDepth(), collectHealth()]);
  return {
    version: VERSION,
    hostname: os.hostname(),
    platform: `${os.platform()} ${os.release()} ${os.arch()}`,
    printers: printers.map((p) => ({ queue: p.queue, state: p.state, accepting: p.accepting, deviceUri: p.deviceUri, makeModel: p.makeModel, media: p.media, jobs: p.jobs })),
    queueDepth: depth,
    health
  };
};

// src/commands.ts
import { existsSync as existsSync3 } from "node:fs";
import { writeFile } from "node:fs/promises";
var trim = (s, n = 18e3) => s.length > n ? s.slice(0, n) + "\n\u2026(truncated)" : s;
var SAFE_QUEUE = /^[A-Za-z0-9_.-]{1,64}$/;
var SAFE_URI = /^[a-z0-9+.-]+:\/\/[^\s"'`;&|<>$\\]{1,300}$/i;
var SAFE_DRIVER = /^[A-Za-z0-9_.:/+ ()-]{1,200}$/;
var SAFE_OPTION_KEY = /^[A-Za-z0-9_.-]{1,40}$/;
var SAFE_OPTION_VALUE = /^[A-Za-z0-9=_.,:+-]{1,80}$/;
var SAFE_TEXT = (s, n = 120) => String(s ?? "").replace(/[^\p{L}\p{N} _.,()/#+:-]/gu, "").slice(0, n);
var DRIVER_FILTER = /everywhere|zebra|dymo|brother|tsc|godex|citizen|sato|bixolon|intermec|datamax|generic|postscript|pcl|raw|cups-pdf/i;
var relayHttp = async (cfg, p) => {
  const method = String(p?.method || "GET").toUpperCase();
  if (!/^(GET|POST|HEAD)$/.test(method)) throw new Error("method not allowed");
  const path5 = String(p?.path || "/");
  if (!path5.startsWith("/") || path5.startsWith("//") || /[\s]/.test(path5)) throw new Error("invalid path");
  const headers = { "User-Agent": "logship-print-agent-relay" };
  for (const k of ["content-type", "accept", "cookie", "accept-language"]) {
    const v = p?.headers?.[k];
    if (v) headers[k] = String(v).slice(0, 4e3);
  }
  if (cfg.cupsAdminUser && cfg.cupsAdminPass) headers.Authorization = "Basic " + Buffer.from(`${cfg.cupsAdminUser}:${cfg.cupsAdminPass}`).toString("base64");
  const body = p?.bodyBase64 ? Buffer.from(String(p.bodyBase64), "base64") : void 0;
  const res = await fetch("http://127.0.0.1:631" + path5, { method, headers, body, redirect: "manual", signal: AbortSignal.timeout(2e4) });
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > 5 * 1024 * 1024) throw new Error("response too large");
  const outHeaders = {};
  for (const k of ["content-type", "location", "cache-control", "last-modified", "etag"]) {
    const v = res.headers.get(k);
    if (v) outHeaders[k] = v;
  }
  const setCookies = typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
  return JSON.stringify({ status: res.status, headers: outHeaders, setCookies, bodyBase64: buf.toString("base64") });
};
var discoverPrinters = async () => {
  const [devs, drvs, ipp] = await Promise.all([run("lpinfo", ["-l", "-v"], 4e4), run("lpinfo", ["-m"], 4e4), run("ippfind", ["-T", "4"], 15e3)]);
  const devices = [];
  let cur = null;
  for (const raw of devs.stdout.split(/\r?\n/)) {
    const line = raw.trim();
    if (line.startsWith("Device:")) {
      cur = {};
      devices.push(cur);
      continue;
    }
    const m = /^([a-z-]+)\s*=\s*(.*)$/.exec(line);
    if (cur && m) cur[m[1]] = m[2];
  }
  const drivers = drvs.stdout.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && DRIVER_FILTER.test(l)).slice(0, 400).map((l) => {
    const sp = l.indexOf(" ");
    return sp > 0 ? { id: l.slice(0, sp), name: l.slice(sp + 1) } : { id: l, name: l };
  });
  const ippUris = ipp.stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  return {
    devices: devices.filter((d) => d.uri && !/^(file|cups-pdf):/.test(d.uri)).map((d) => ({ uri: d.uri, class: d.class, info: d.info, makeModel: d["make-and-model"], deviceId: d["device-id"] })),
    ippEverywhere: ippUris,
    drivers,
    note: devs.code !== 0 ? devs.stderr : void 0
  };
};
var addPrinter = async (p) => {
  const queue = String(p?.queue || "").trim();
  const uri = String(p?.deviceUri || "").trim();
  const driver = String(p?.driver || "everywhere").trim();
  if (!SAFE_QUEUE.test(queue)) throw new Error("invalid queue name (A-Z a-z 0-9 _ . -)");
  if (!SAFE_URI.test(uri)) throw new Error("invalid device URI");
  if (!SAFE_DRIVER.test(driver)) throw new Error("invalid driver id");
  const args = ["-p", queue, "-E", "-v", uri, "-o", "printer-is-shared=false", "-o", "printer-error-policy=retry-job"];
  if (driver === "raw") args.push("-m", "raw");
  else args.push("-m", driver);
  if (p?.description) args.push("-D", SAFE_TEXT(p.description));
  if (p?.location) args.push("-L", SAFE_TEXT(p.location));
  const r = await run("lpadmin", args, 9e4);
  if (r.code !== 0) throw new Error(`lpadmin failed: ${r.stderr || r.stdout}`);
  const out = [`queue ${queue} created (${driver} @ ${uri})`];
  if (p?.media && SAFE_OPTION_VALUE.test(String(p.media))) {
    const o = await run("lpoptions", ["-p", queue, "-o", `media=${p.media}`], 2e4);
    out.push(o.code === 0 ? `default media ${p.media}` : `media option failed: ${o.stderr}`);
  }
  await run("cupsaccept", [queue]);
  await run("cupsenable", [queue]);
  return out.join("\n");
};
var setQueueOptions = async (p) => {
  const queue = String(p?.queue || "").trim();
  if (!SAFE_QUEUE.test(queue)) throw new Error("invalid queue name");
  const opts = p?.options && typeof p.options === "object" ? p.options : {};
  const args = ["-p", queue];
  for (const [k, v] of Object.entries(opts)) {
    if (!SAFE_OPTION_KEY.test(k) || !SAFE_OPTION_VALUE.test(String(v))) throw new Error(`invalid option ${k}`);
    args.push("-o", `${k}=${v}`);
  }
  if (args.length === 2) throw new Error("no options given");
  const r = await run("lpoptions", args, 2e4);
  if (r.code !== 0) throw new Error(r.stderr || r.stdout);
  return `options set on ${queue}: ${Object.entries(opts).map(([k, v]) => `${k}=${v}`).join(" ")}`;
};
var queueControl = async (p) => {
  const queue = String(p?.queue || "").trim();
  const action = String(p?.action || "");
  if (!SAFE_QUEUE.test(queue)) throw new Error("invalid queue name");
  const map = {
    enable: ["cupsenable", queue],
    disable: ["cupsdisable", queue],
    accept: ["cupsaccept", queue],
    reject: ["cupsreject", queue],
    "cancel-jobs": ["cancel", "-a", queue]
  };
  const cmd2 = map[action];
  if (!cmd2) throw new Error("unknown action");
  const r = await run(cmd2[0], cmd2.slice(1), 2e4);
  if (r.code !== 0) throw new Error(r.stderr || r.stdout);
  return `${action} ${queue}: ok`;
};
var testPrint = async (cfg, p) => {
  const queue = String(p?.queue || "").trim();
  if (!SAFE_QUEUE.test(queue)) throw new Error("invalid queue name");
  let file = "/usr/share/cups/data/testprint";
  if (!existsSync3(file)) {
    file = `${cfg.spoolDir}/testpage.txt`;
    await writeFile(file, `LogShip Print Agent test page
queue: ${queue}
${(/* @__PURE__ */ new Date()).toISOString()}
`);
  }
  const r = await submit(queue, ["-o", "fit-to-page"], file);
  if (!r.ok) throw new Error(r.stderr || r.stdout || "lp failed");
  return `test page sent to ${queue} (${r.requestId})`;
};
var handleCommand = async (cfg, api, c, ctx = {}) => {
  log.info(`command #${c.id}: ${c.command}`);
  let ok = true;
  let result = "";
  let inventoryChanged = false;
  try {
    switch (c.command) {
      case "lpstat": {
        const r = await lpstatAll();
        result = trim(r.stdout + (r.stderr ? "\n" + r.stderr : ""));
        break;
      }
      case "restart-cups": {
        const r = await restartCups();
        ok = r.code === 0;
        result = ok ? "cups restarted" : r.stderr;
        inventoryChanged = true;
        break;
      }
      case "cancel-all": {
        const r = await cancelAll();
        ok = r.code === 0;
        result = r.stdout || r.stderr || "all CUPS jobs cancelled";
        break;
      }
      case "journal": {
        const r = await run("journalctl", ["-u", "logship-print-agent", "-n", "400", "--no-pager"], 3e4);
        result = trim(r.stdout || r.stderr);
        break;
      }
      case "update": {
        const r = await run("systemd-run", [
          "--unit=logship-print-agent-update",
          "--collect",
          "--description=LogShip Print Agent update",
          "/bin/sh",
          "-c",
          "apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --only-upgrade logship-print-agent"
        ], 2e4);
        ok = r.code === 0;
        result = ok ? "update started (apt-get --only-upgrade logship-print-agent); the new version reports with the next heartbeat" : r.stderr || r.stdout;
        break;
      }
      case "reboot": {
        const r = await run("systemd-run", ["--on-active=5", "--collect", "systemctl", "reboot"], 1e4);
        ok = r.code === 0;
        result = ok ? "reboot scheduled in 5 s" : r.stderr;
        break;
      }
      case "backup-now": {
        const tar = await createCupsBackup();
        const up = await api.uploadBackup(tar);
        result = `uploaded /etc/cups backup, ${up?.bytes ?? tar.length} bytes`;
        break;
      }
      case "support-tunnel-on": {
        if (!cfg.allowSupportTunnel) throw new Error("support tunnel disabled on this device (ALLOW_SUPPORT_TUNNEL=0 in agent.env)");
        const r = await run("systemctl", ["start", cfg.supportUnit], 3e4);
        ok = r.code === 0;
        if (ok) await run("systemd-run", ["--on-active=8h", "--collect", "--unit=logship-print-support-stop", "systemctl", "stop", cfg.supportUnit], 1e4);
        result = ok ? `support tunnel started (${cfg.supportUnit}), auto-stop in 8 h` : r.stderr || "could not start support tunnel \u2013 is /etc/logship-print-agent/support.env configured?";
        break;
      }
      case "support-tunnel-off": {
        const r = await run("systemctl", ["stop", cfg.supportUnit], 3e4);
        ok = r.code === 0;
        result = ok ? "support tunnel stopped" : r.stderr;
        break;
      }
      // ── remote printer administration ─────────────────────────────────────
      case "discover-printers": {
        result = JSON.stringify(await discoverPrinters());
        break;
      }
      case "add-printer": {
        result = await addPrinter(c.payload);
        inventoryChanged = true;
        break;
      }
      case "remove-printer": {
        const queue = String(c.payload?.queue || "").trim();
        if (!SAFE_QUEUE.test(queue)) throw new Error("invalid queue name");
        const r = await run("lpadmin", ["-x", queue], 3e4);
        ok = r.code === 0;
        result = ok ? `queue ${queue} removed` : r.stderr || r.stdout;
        inventoryChanged = true;
        break;
      }
      case "set-queue-option": {
        result = await setQueueOptions(c.payload);
        inventoryChanged = true;
        break;
      }
      case "queue-control": {
        result = await queueControl(c.payload);
        inventoryChanged = true;
        break;
      }
      case "test-print": {
        result = await testPrint(cfg, c.payload);
        break;
      }
      case "list-queues": {
        result = JSON.stringify(await listQueues(cfg.ppdDir));
        break;
      }
      case "http": {
        if (!cfg.allowHttpRelay) throw new Error("CUPS web relay disabled on this device (ALLOW_HTTP_RELAY=0 in agent.env)");
        result = await relayHttp(cfg, c.payload);
        break;
      }
      default:
        ok = false;
        result = `unknown command ${c.command}`;
    }
  } catch (e) {
    ok = false;
    result = e?.message || String(e);
  }
  try {
    await api.commandResult(c.id, ok, result);
  } catch (e) {
    log.warn("could not post command result:", e?.message || e);
  }
  if (inventoryChanged && ctx.refreshInventory) {
    try {
      await ctx.refreshInventory();
    } catch (e) {
      log.warn("inventory refresh failed:", e?.message || e);
    }
  }
};

// src/setup-server.ts
import http from "node:http";
import os2 from "node:os";
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var ago = (ts2) => !ts2 ? "nie" : `${Math.round((Date.now() - ts2) / 1e3)} s`;
var page = (title, body) => `<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title><style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:900px;margin:24px auto;padding:0 16px;color:#111;background:#f7f7f8}
h1{font-size:1.4rem;margin:0 0 4px}.sub{color:#666;margin:0 0 18px}.card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:16px;margin-bottom:14px}
table{width:100%;border-collapse:collapse;font-size:.9rem}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid #eee}th{color:#555;font-weight:600}
.ok{color:#16a34a;font-weight:600}.bad{color:#dc2626;font-weight:600}code{background:#f1f5f9;padding:1px 5px;border-radius:4px}
input,button{font:inherit;padding:8px 10px;border:1px solid #cbd5e1;border-radius:6px}input{width:100%;box-sizing:border-box;margin:4px 0 10px}
button{background:#0f172a;color:#fff;border-color:#0f172a;cursor:pointer}button.sec{background:#fff;color:#0f172a}.row{display:flex;gap:10px;flex-wrap:wrap}.muted{color:#777;font-size:.85rem}
</style></head><body><h1>LogShip Print Agent</h1><p class="sub">${esc(os2.hostname())} \xB7 Version ${esc(VERSION)}</p>${body}</body></html>`;
var readBody = (req) => new Promise((resolve) => {
  let b = "";
  req.on("data", (d) => {
    b += d;
    if (b.length > 1e6) req.destroy();
  });
  req.on("end", () => resolve(b));
});
var startSetupServer = (state) => {
  const { cfg } = state;
  const srv = http.createServer(async (req, res) => {
    const send = (code, html) => {
      res.writeHead(code, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
      res.end(html);
    };
    try {
      const url = new URL(req.url || "/", "http://x");
      if (req.method === "POST" && url.pathname === "/enroll") {
        const form = new URLSearchParams(await readBody(req));
        const instanceUrl = String(form.get("url") || "").trim().replace(/\/+$/, "");
        const code = String(form.get("code") || "").trim().toUpperCase();
        const name = String(form.get("name") || "").trim() || cfg.name;
        if (!/^https?:\/\//.test(instanceUrl) || !code) return send(400, page("Fehler", `<div class="card bad">URL oder Code fehlt.</div><p><a href="/">zur\xFCck</a></p>`));
        const r = await Api.enroll(instanceUrl, code, { name, hostname: os2.hostname(), platform: `${os2.platform()} ${os2.arch()}`, version: VERSION });
        writeEnvFile({ LOGSHIP_URL: instanceUrl, LOGSHIP_AGENT_TOKEN: r.token, LOGSHIP_AGENT_NAME: JSON.stringify(r.name || name) }, cfg.envFile);
        log.info(`enrolled as agent #${r.agentId} "${r.name}" at ${instanceUrl} via setup page \u2014 restarting`);
        send(200, page("Verbunden", `<div class="card"><p class="ok">Erfolgreich mit ${esc(instanceUrl)} verbunden (Agent #${r.agentId}, \u201E${esc(r.name)}\u201C).</p><p>Der Dienst startet neu. Diese Seite in ein paar Sekunden neu laden.</p></div>`));
        setTimeout(() => process.exit(0), 800);
        return;
      }
      if (req.method === "POST" && url.pathname === "/test-print") {
        const form = new URLSearchParams(await readBody(req));
        const queue = String(form.get("queue") || "").trim();
        if (!/^[A-Za-z0-9_.-]{1,64}$/.test(queue)) return send(400, page("Fehler", '<div class="card bad">Ung\xFCltige Warteschlange.</div>'));
        const r = await submit(queue, ["-o", "fit-to-page"], "/usr/share/cups/data/testprint");
        return send(200, page("Testdruck", `<div class="card"><p class="${r.ok ? "ok" : "bad"}">${r.ok ? "Testseite an " + esc(queue) + " gesendet (" + esc(r.requestId) + ")" : "Fehler: " + esc(r.stderr || r.stdout)}</p><p><a href="/">zur\xFCck</a></p></div>`));
      }
      if (url.pathname === "/health") {
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ ok: true, enrolled: state.enrolled, connected: state.connected, version: VERSION }));
      }
      if (!state.enrolled) {
        return send(200, page("Einrichtung", `<div class="card"><h3>Mit LogShip verbinden</h3>
<p class="muted">Code und URL stammen aus LogShip \u2192 Einstellungen \u2192 Drucker \u2192 \u201EPrint-Agents\u201C \u2192 \u201EEnrolment-Code erzeugen\u201C.</p>
<form method="post" action="/enroll"><label>Instanz-URL</label><input name="url" placeholder="https://erp.ihre-firma.de" required>
<label>Enrolment-Code</label><input name="code" placeholder="LSPA-XXXX-XXXX-XXXX" required style="text-transform:uppercase">
<label>Ger\xE4tename</label><input name="name" placeholder="z. B. Lager Halle 2 \u2013 Druckbox" value="${esc(cfg.name)}">
<button type="submit">Verbinden</button></form></div>
<div class="card"><h3>Drucker</h3><p>USB-Etikettendrucker (Zebra) werden automatisch eingerichtet. Netzwerk- und A4-Drucker \xFCber die CUPS-Oberfl\xE4che anlegen: <a href="http://${esc(os2.hostname())}.local:631/admin" target="_blank">http://${esc(os2.hostname())}.local:631</a></p></div>`));
      }
      const queues = state.printers.map((p) => `<tr><td><code>${esc(p.queue)}</code></td><td>${esc(p.makeModel || "")}<div class="muted">${esc(p.deviceUri || "")}</div></td><td>${esc(p.state)}${p.accepting === false ? ' <span class="bad">nimmt nicht an</span>' : ""}</td><td>${p.media ? esc(p.media.w + " \xD7 " + p.media.h + " mm") : "\u2013"}</td><td>${esc(p.jobs ?? 0)}</td><td><form method="post" action="/test-print" style="margin:0"><input type="hidden" name="queue" value="${esc(p.queue)}"><button class="sec" type="submit">Testseite</button></form></td></tr>`).join("");
      const jobs = state.recentJobs.map((j) => `<tr><td>${j.id}</td><td><code>${esc(j.queue)}</code></td><td>${esc(j.fileName)}</td><td class="${j.status === "failed" ? "bad" : "ok"}">${esc(j.status)}</td><td class="muted">${esc(j.error || "")}</td><td class="muted">${ago(j.ts)}</td></tr>`).join("");
      send(200, page("Status", `<div class="card"><h3>Verbindung</h3>
<table><tr><th>Instanz</th><td><a href="${esc(cfg.url)}" target="_blank">${esc(cfg.url)}</a></td></tr>
<tr><th>Ger\xE4tename</th><td>${esc(cfg.name)}</td></tr>
<tr><th>Status</th><td class="${state.connected ? "ok" : "bad"}">${state.connected ? "verbunden" : "nicht verbunden"} <span class="muted">\xB7 letzter Abruf vor ${ago(state.lastPoll)}, Heartbeat vor ${ago(state.lastHeartbeat)}</span></td></tr>
<tr><th>Wartend auf Server</th><td>${state.queuedOnServer}</td></tr>
${state.lastError ? `<tr><th>Letzter Fehler</th><td class="bad">${esc(state.lastError)}</td></tr>` : ""}</table></div>
<div class="card"><h3>Warteschlangen (CUPS)</h3>${queues ? `<table><tr><th>Name</th><th>Modell</th><th>Zustand</th><th>Etikett</th><th>Offen</th><th></th></tr>${queues}</table>` : '<p class="muted">Noch keine Warteschlangen. USB-Drucker anstecken oder in CUPS anlegen.</p>'}
<p class="muted">Drucker verwalten: <a href="http://${esc(os2.hostname())}.local:631/admin" target="_blank">CUPS-Verwaltung</a>. Welche LogShip-Drucker \xFCber dieses Ger\xE4t drucken, wird in LogShip unter Einstellungen \u2192 Drucker pro Drucker festgelegt.</p></div>
<div class="card"><h3>Letzte Auftr\xE4ge</h3>${jobs ? `<table><tr><th>#</th><th>Warteschlange</th><th>Datei</th><th>Status</th><th></th><th>vor</th></tr>${jobs}</table>` : '<p class="muted">Noch keine Auftr\xE4ge.</p>'}</div>`));
    } catch (e) {
      log.warn("setup page error:", e?.message || e);
      send(500, page("Fehler", `<div class="card bad">${esc(e?.message || e)}</div><p><a href="/">zur\xFCck</a></p>`));
    }
  });
  srv.on("error", (e) => log.warn(`setup page not available on :${cfg.setupPort}: ${e?.message || e}`));
  srv.listen(cfg.setupPort, cfg.setupBind, () => log.info(`setup/status page on http://${os2.hostname()}:${cfg.setupPort}`));
  return srv;
};

// src/worker.ts
var SAFE_OPTION = /^[A-Za-z0-9=_.,:+\-]{1,80}$/;
var tokenizeOptions = (options) => {
  const out = [];
  const t = String(options || "").trim().split(/\s+/).filter(Boolean);
  for (let i = 0; i < t.length; i++) {
    if (/^-(o|n|t|H|P|q)$/.test(t[i]) && t[i + 1] && SAFE_OPTION.test(t[i + 1])) {
      out.push(t[i], t[i + 1]);
      i++;
      continue;
    }
    throw new Error(`unsafe print option: ${t[i]}`);
  }
  return out;
};
var Downloader = class {
  active = 0;
  waiting = [];
  api;
  limit;
  constructor(api, limit = 4) {
    this.api = api;
    this.limit = limit;
  }
  async fetch(job) {
    if (job.content) return Buffer.from(job.content, "base64");
    if (this.active >= this.limit) await new Promise((r) => this.waiting.push(r));
    this.active++;
    try {
      return await this.api.file(job.id);
    } finally {
      this.active--;
      this.waiting.shift()?.();
    }
  }
};
var QueueWorker = class {
  pending = [];
  running = false;
  queue;
  ctx;
  constructor(queue, ctx) {
    this.queue = queue;
    this.ctx = ctx;
  }
  push(job) {
    if (this.pending.some((p) => p.job.id === job.id)) return;
    const file = this.ctx.dl.fetch(job);
    file.catch(() => {
    });
    this.pending.push({ job, file });
    this.pending.sort((a, b) => a.job.id - b.job.id);
    if (!this.running) {
      this.running = true;
      this.loop().finally(() => {
        this.running = false;
      });
    }
  }
  async loop() {
    while (this.pending.length) {
      const { job, file } = this.pending.shift();
      await this.handle(job, file);
    }
  }
  async handle(job, file) {
    const { cfg, ledger, tracker, state, ack } = this.ctx;
    const known = ledger.get(job.id);
    if (known) {
      log.info(`job ${job.id} already spooled as ${known.cupsJobId} \u2014 ack only (resend)`);
      ack({ id: job.id, status: "spooled", cupsJobId: known.cupsJobId, output: "already spooled (idempotent resend)" });
      return;
    }
    const target = path4.join(cfg.spoolDir, `${job.id}-${job.fileName.replace(/[^A-Za-z0-9_.-]/g, "_")}`);
    try {
      const buf = await file;
      await writeFile2(target, buf);
      const tokens = tokenizeOptions(job.options);
      let waited = 0;
      while (tracker.outstandingFor(this.queue) >= cfg.maxActivePerQueue) {
        if (waited === 0) log.info(`${this.queue}: ${tracker.outstandingFor(this.queue)} jobs open in CUPS \u2014 waiting before job ${job.id}`);
        await sleep(500);
        waited += 500;
      }
      let r = await submit(this.queue, tokens, target);
      for (let attempt = 0; !r.ok && /too many active jobs|server-error-busy|temporarily/i.test(r.stderr || "") && attempt < 360; attempt++) {
        if (attempt === 0) log.warn(`${this.queue}: CUPS busy ("${(r.stderr || "").trim()}") \u2014 retrying job ${job.id} until the queue drains`);
        await sleep(5e3);
        r = await submit(this.queue, tokens, target);
      }
      if (!r.ok) {
        const err = (r.stderr || r.stdout || "lp failed").trim();
        log.warn(`job ${job.id} \u2192 ${this.queue}: lp FAILED: ${err}`);
        ack({ id: job.id, status: "failed", output: r.stdout, error: err });
        state.recent(job, "failed", err);
        await unlink(target).catch(() => {
        });
        return;
      }
      ledger.add(job.id, r.requestId, this.queue, target);
      log.info(`job ${job.id} \u2192 ${this.queue} spooled as ${r.requestId} (${buf.length} B, ${job.options || "no options"})`);
      ack({ id: job.id, status: "spooled", cupsJobId: r.requestId, output: r.stdout.trim() });
      state.recent(job, "spooled");
      tracker.track(job.id, r.requestId, this.queue, target, job);
    } catch (e) {
      const err = e?.message || String(e);
      log.warn(`job ${job.id} \u2192 ${this.queue}: ${err}`);
      ack({ id: job.id, status: "failed", error: err });
      state.recent(job, "failed", err);
      await unlink(target).catch(() => {
      });
    }
  }
};
var CompletionTracker = class {
  tracked = /* @__PURE__ */ new Map();
  ack;
  state;
  ledger;
  constructor(cfg, ack, state, ledger) {
    this.ack = ack;
    this.state = state;
    this.ledger = ledger;
    for (const { jobId, entry } of ledger.open()) {
      if (!entry.cupsJobId) {
        ledger.finish(jobId);
        continue;
      }
      const job = { id: jobId, queue: entry.queue, fileName: path4.basename(entry.file || ""), batchId: null, options: "", fileSize: 0, source: "", createdAt: "", attempt: 1, content: null, fileUrl: null };
      this.tracked.set(jobId, { cupsJobId: entry.cupsJobId, queue: entry.queue, file: entry.file || "", since: entry.ts, job, restored: true });
    }
    if (this.tracked.size) log.info(`restored ${this.tracked.size} spooled job(s) from the ledger for completion tracking`);
    setInterval(() => this.tick().catch((e) => log.warn("completion tick failed:", e?.message || e)), cfg.completionPollMs).unref();
  }
  track(jobId, cupsJobId, queue, file, job) {
    this.tracked.set(jobId, { cupsJobId, queue, file, since: Date.now(), job });
  }
  /** Server-side 'spooled' jobs without completion (handed over on a fresh start): observe them like restored ones. */
  reconcile(items) {
    let n = 0;
    for (const it of items) {
      if (!it.cupsJobId || this.tracked.has(it.id)) continue;
      this.ledger.adopt(it.id, it.cupsJobId, it.queue);
      const job = { id: it.id, queue: it.queue, fileName: "", batchId: null, options: "", fileSize: 0, source: "", createdAt: "", attempt: 1, content: null, fileUrl: null };
      this.tracked.set(it.id, { cupsJobId: it.cupsJobId, queue: it.queue, file: "", since: Date.now(), job, restored: true });
      n++;
    }
    if (n) log.info(`reconciling ${n} job(s) the instance still had as spooled`);
  }
  get outstanding() {
    return this.tracked.size;
  }
  outstandingFor(queue) {
    let n = 0;
    for (const t of this.tracked.values()) if (t.queue === queue) n++;
    return n;
  }
  async tick() {
    if (!this.tracked.size) return;
    const [pending, completed] = await Promise.all([pendingJobIds(), completedJobIds()]);
    for (const [jobId, t] of this.tracked) {
      if (pending.has(t.cupsJobId)) {
        t.missingSince = void 0;
        continue;
      }
      if (completed.has(t.cupsJobId)) {
        this.tracked.delete(jobId);
        this.ledger.finish(jobId);
        this.ack({ id: jobId, status: "completed", cupsJobId: t.cupsJobId });
        this.state.recent(t.job, "completed");
        if (t.file) unlink(t.file).catch(() => {
        });
        continue;
      }
      t.missingSince = t.missingSince || Date.now();
      if (Date.now() - t.missingSince > 1e4) {
        this.tracked.delete(jobId);
        this.ledger.finish(jobId);
        if (t.restored) {
          this.ack({ id: jobId, status: "completed", cupsJobId: t.cupsJobId, output: "completed while the agent was restarting (no longer in CUPS history)" });
          this.state.recent(t.job, "completed");
        } else {
          const err = "CUPS job vanished (cancelled or aborted on the device \u2014 printer offline / paper out?)";
          this.ack({ id: jobId, status: "failed", cupsJobId: t.cupsJobId, error: err });
          this.state.recent(t.job, "failed", err);
        }
        if (t.file) unlink(t.file).catch(() => {
        });
      }
    }
  }
};
var AckBatcher = class {
  buf = [];
  timer = null;
  api;
  constructor(api) {
    this.api = api;
  }
  push(a) {
    this.buf.push(a);
    if (!this.timer) this.timer = setTimeout(() => this.flush(), 300);
  }
  async flush() {
    this.timer = null;
    const batch = this.buf.splice(0, 500);
    if (!batch.length) return;
    try {
      await this.api.ack(batch);
    } catch (e) {
      log.warn(`ack of ${batch.length} job(s) failed, retrying: ${e?.message || e}`);
      this.buf.unshift(...batch);
      this.timer = setTimeout(() => this.flush(), 3e3);
    }
    if (this.buf.length && !this.timer) this.timer = setTimeout(() => this.flush(), 300);
  }
};
var runService = async (cfg) => {
  const state = {
    cfg,
    version: void 0,
    enrolled: isEnrolled(cfg),
    connected: false,
    lastPoll: 0,
    lastHeartbeat: 0,
    lastError: "",
    queuedOnServer: 0,
    printers: [],
    recentJobs: [],
    recent(job, status, error) {
      this.recentJobs.unshift({ id: job.id, queue: job.queue, fileName: job.fileName, status, error, ts: Date.now() });
      if (this.recentJobs.length > 50) this.recentJobs.length = 50;
    }
  };
  startSetupServer(state);
  if (!isEnrolled(cfg)) {
    log.warn(`not enrolled \u2014 open http://${os3.hostname()}.local:${cfg.setupPort} (or run: logship-print-agent enroll --url \u2026 --code \u2026)`);
    for (; ; ) await sleep(6e4);
  }
  const api = new Api(cfg.url, cfg.token);
  const ledger = new Ledger(cfg.stateDir);
  const acks = new AckBatcher(api);
  const ack = (a) => acks.push(a);
  const tracker = new CompletionTracker(cfg, ack, state, ledger);
  const ctx = { cfg, api, ledger, dl: new Downloader(api, 4), tracker, state, ack };
  const workers = /* @__PURE__ */ new Map();
  const worker = (q) => {
    let w = workers.get(q);
    if (!w) {
      w = new QueueWorker(q, ctx);
      workers.set(q, w);
    }
    return w;
  };
  const cmdCtx = { refreshInventory: async () => {
    await heartbeat();
  } };
  const heartbeat = async () => {
    try {
      const body = await buildHeartbeat(cfg);
      state.printers = body.printers;
      const res = await api.heartbeat(body);
      state.lastHeartbeat = Date.now();
      state.queuedOnServer = res.queued;
      for (const c of res.commands || []) handleCommand(cfg, api, c, cmdCtx);
    } catch (e) {
      state.lastError = e?.message || String(e);
      log.warn("heartbeat failed:", state.lastError);
    }
  };
  heartbeat();
  setInterval(heartbeat, cfg.heartbeatSeconds * 1e3).unref();
  if (cfg.backupEnabled) scheduleBackups(api);
  log.info(`LogShip Print Agent "${cfg.name}" connected to ${cfg.url} \u2014 long-poll ${cfg.pollWait}s / ${cfg.pollMax} jobs, heartbeat ${cfg.heartbeatSeconds}s`);
  let backoff = 1e3;
  let fresh = true;
  for (; ; ) {
    try {
      const res = await api.next(cfg.pollWait, cfg.pollMax, fresh);
      fresh = false;
      if (res.reconcile?.length) tracker.reconcile(res.reconcile);
      state.connected = true;
      state.lastPoll = Date.now();
      state.lastError = "";
      backoff = 1e3;
      for (const c of res.commands || []) handleCommand(cfg, api, c, cmdCtx);
      for (const j of res.jobs || []) worker(j.queue).push(j);
    } catch (e) {
      state.connected = false;
      state.lastError = e?.message || String(e);
      if (e instanceof ApiError && e.unauthorized) {
        log.error(`instance rejected our token (${e.status}) \u2014 agent revoked? Re-enrol with a new code. Retrying in 60 s.`);
        await sleep(6e4);
        continue;
      }
      log.warn(`poll failed (${state.lastError}), retry in ${Math.round(backoff / 1e3)} s`);
      await sleep(backoff);
      backoff = Math.min(backoff * 2, 6e4);
    }
  }
};

// src/cli.ts
var argv = process.argv.slice(2);
var cmd = argv[0] || "run";
var opt = (name) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 ? argv[i + 1] : void 0;
};
var main = async () => {
  const cfg = loadConfig();
  switch (cmd) {
    case "run":
      return runService(cfg);
    case "enroll": {
      const url = String(opt("url") || cfg.url || "").replace(/\/+$/, "");
      const code = String(opt("code") || "").trim().toUpperCase();
      const name = opt("name") || cfg.name;
      if (!url || !code) {
        console.error('usage: logship-print-agent enroll --url https://erp.example --code LSPA-XXXX-XXXX-XXXX [--name "Lager 1"]');
        process.exit(2);
      }
      const r = await Api.enroll(url, code, { name, hostname: os4.hostname(), platform: `${os4.platform()} ${os4.arch()}`, version: VERSION });
      writeEnvFile({ LOGSHIP_URL: url, LOGSHIP_AGENT_TOKEN: r.token, LOGSHIP_AGENT_NAME: JSON.stringify(r.name || name) }, cfg.envFile);
      console.log(`enrolled as agent #${r.agentId} "${r.name}" at ${url} (${r.instance?.name || "LogShip"}) \u2014 token saved to ${cfg.envFile}`);
      console.log("restart the service:  systemctl restart logship-print-agent");
      return;
    }
    case "status": {
      console.log(`logship-print-agent ${VERSION} on ${os4.hostname()} (${os4.platform()} ${os4.arch()})`);
      console.log(isEnrolled(cfg) ? `instance: ${cfg.url}  agent name: ${cfg.name}` : "NOT ENROLLED \u2014 run: logship-print-agent enroll --url \u2026 --code \u2026");
      const [queues, depth] = await Promise.all([listQueues(cfg.ppdDir), queueDepth()]);
      if (!queues.length) console.log("no CUPS queues");
      for (const q of queues) console.log(`  ${q.queue.padEnd(20)} ${q.state.padEnd(9)} ${q.accepting ? "accepting" : "NOT accepting"}  ${q.media ? `${q.media.w}\xD7${q.media.h} mm` : "-"}  ${q.makeModel}  ${q.deviceUri}  open: ${depth[q.queue] || 0}`);
      if (isEnrolled(cfg)) {
        try {
          const r = await fetch(`${cfg.url}/api/print-agent/heartbeat`, { method: "POST", headers: { Authorization: `Bearer ${cfg.token}`, "Content-Type": "application/json" }, body: JSON.stringify({ version: VERSION }), signal: AbortSignal.timeout(15e3) });
          console.log(`instance reachable: ${r.status} ${r.ok ? "OK" : "ERROR (token revoked?)"}`);
        } catch (e) {
          console.log(`instance NOT reachable: ${e?.message || e}`);
        }
      }
      return;
    }
    case "restore-cups": {
      if (!isEnrolled(cfg)) {
        console.error("not enrolled");
        process.exit(2);
      }
      const ok = await restoreCupsBackup(new Api(cfg.url, cfg.token));
      process.exit(ok ? 0 : 1);
    }
    case "backup-now": {
      if (!isEnrolled(cfg)) {
        console.error("not enrolled");
        process.exit(2);
      }
      await uploadCupsBackup(new Api(cfg.url, cfg.token));
      return;
    }
    case "version":
      console.log(VERSION);
      return;
    default:
      console.error(`unknown command ${cmd}`);
      process.exit(2);
  }
};
main().catch((e) => {
  log.error(e);
  process.exit(1);
});
